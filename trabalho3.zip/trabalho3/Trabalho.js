import * as THREE from 'three';
import Stats from '../build/jsm/libs/stats.module.js';
import { GLTFLoader } from '../../build/jsm/loaders/GLTFLoader.js';
import KeyboardState from '../libs/util/KeyboardState.js'
import {
    onWindowResize,
    degreesToRadians,
    createGroundPlaneWired
} from "../libs/util/util.js";

import { default as Plane } from './classes/Plane.js';
import { default as EnemyAir } from './classes/EnemyAir.js';
import { default as GroundEnemy } from './classes/GroundEnemy.js';
import { default as Cura } from './classes/Cura.js';
import { default as Plano } from './classes/Extras/Plano.js';
import { Water } from './external/Water2.js';
import { OrbitControls } from "../build/jsm/controls/OrbitControls.js";

import {
    colisionPlaneEnemy,
    colisionBulletEnemy,
    colisionBulletPlane,
    colisionMissileEnemy,
    colisionMissilePlane,
    colisionCuraPlane
} from "./src/Colisoes.js"

import {
   criarCura,
   verticalCura,
   takeOneHealthBar,
   gainOneHealthBar,
   resetHealthBar
} from "./src/Life.js"

import {
    loadPlaneGTLF,
    loadToonTankObj
 } from "./src/Loader.js"

// import {
//     chamaAdversario,
//     criarAdversario,
//     criarAdversarioChao,
//     movimentarAdversario
// } from "./src/Adversarios.js"

var scene = new THREE.Scene();    // Create main scene

var renderer = new THREE.WebGLRenderer({alpha: true});
document.getElementById("webgl-output").appendChild(renderer.domElement);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.VSMShadowMap; // default
renderer.autoClear = false;


var clock = new THREE.Clock();
clock.start();
var stats = new Stats(); //Pra ver os status do FPS
//********************************************//
// Criando a luz
var position = new THREE.Vector3(0, 100, 100);
var dirLight = new THREE.DirectionalLight("rgb(255,255,255)");
setDirectionalLighting(position);
function setDirectionalLighting(position) {
    dirLight.position.copy(position);
    dirLight.shadow.mapSize.width = 512;
    dirLight.shadow.mapSize.height = 512;
    dirLight.castShadow = true;
    dirLight.shadow.camera.near = .1;
    dirLight.shadow.camera.far = 600;
    dirLight.shadow.camera.left = -110;
    dirLight.shadow.camera.right = 110;
    dirLight.shadow.camera.top = 200;
    dirLight.shadow.camera.bottom = -200;
    scene.add(dirLight);
}
//********************************************//
//Criando a camera
var camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 300);
camera.position.set(0, 100, 70);
camera.lookAt(0, 15, 0);
scene.add(camera);
var camPosition = new THREE.Vector3( 0, -200, 30 );
var vcWidth = 400; 
var vcHeidth = 300; 
var virtualCamera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 1, 300); 
virtualCamera.position.copy(camPosition);
scene.add(virtualCamera);
//********************************************//

const loadingManager = new THREE.LoadingManager( () => {
    let loadingScreen = document.getElementById( 'loading-screen' );
    loadingScreen.transition = 0;
    loadingScreen.style.setProperty('--speed1', '0');  
    loadingScreen.style.setProperty('--speed2', '0');  
    loadingScreen.style.setProperty('--speed3', '0');      
  
    let button  = document.getElementById("myBtn")
    button.style.backgroundColor = 'Red';
    button.innerHTML = 'Click to Enter';
    button.addEventListener("click", onButtonPressed);
  });

function onButtonPressed() {
    const loadingScreen = document.getElementById( 'loading-screen' );
    loadingScreen.transition = 0;
    loadingScreen.classList.add( 'fade-out' );
    loadingScreen.addEventListener( 'transitionend', (e) => {
      const element = e.target;
      element.remove();  
    });  
    play = true
    // Config and play the loaded audio
    // let sound = new THREE.Audio( new THREE.AudioListener() );
    // audioLoader.load( audioPath, function( buffer ) {
    //   sound.setBuffer( buffer );
    //   sound.setLoop( true );
    //   sound.play(); 
    // });
  }

//********************************************//
//********************************************//

const planos = new Plano(scene);

//********************************************//
//Para usar o Keyboard
var keyboard = new KeyboardState();
//********************************************//
// Carregando os gltfs
var loader = new GLTFLoader(loadingManager);
var obj;
var tecoTecoObj;
var tieFifhterObj;
var alienPurpleObj;
var toonTankObj;
var playVector = [false, false, false, false, false];
const afterLoadPlane = (object) => {
    planeClass.setObj(object);
    scene.add(object);
    planeHolder = planeClass.obj;
    playVector[0] = true;
    // play = true;
};
const afterLoadEnemy = (enemy, object) => {
    let objCopy = new THREE.Object3D();
    objCopy.copy(object);
    enemy.setObj(objCopy);
    scene.add(objCopy);
    // play = true;
};
//Criando o avião
const planeClass = new Plane();
var planeHolder = new THREE.Object3D();
scene.add(planeHolder);

loadPlaneGTLF(loader, planeClass, playVector, planeHolder, scene);

loader.load('./assets/ToonTank.glb', function (gltf) {
    toonTankObj = gltf.scene;
    toonTankObj.position.set(0,46,0);
    toonTankObj.scale.set(3,3,3);
    toonTankObj.name = 'airplane';
    toonTankObj.visible = true;
    toonTankObj.traverse(function (child) {
        if (child) {
            child.castShadow = true;
        }
    });
    // afterLoadPlane(obj);
    playVector[1] = true;
}, onProgress, null);
loader.load('./assets/TecoTeco.glb', function (gltf) {
    tecoTecoObj = gltf.scene;
    tecoTecoObj.position.set(0,46,0);
    tecoTecoObj.scale.set(2,2,2);
    tecoTecoObj.name = 'enemy';
    tecoTecoObj.visible = true;
    tecoTecoObj.traverse(function (child) {
        if (child) {
            child.castShadow = true;
        }
    });
    playVector[2] = true;
}, onProgress, null);
loader.load('./assets/tieFighter.glb', function (gltf) {
    tieFifhterObj = gltf.scene;
    tieFifhterObj.position.set(0,46,0);
    tieFifhterObj.scale.set(2,2,2);
    tieFifhterObj.name = 'enemy';
    tieFifhterObj.visible = true;
    tieFifhterObj.traverse(function (child) {
        if (child) {
            child.castShadow = true;
        }
    });
    playVector[3] = true;
}, onProgress, null);
loader.load('./assets/AlienPurple.glb', function (gltf) {
    alienPurpleObj = gltf.scene;
    alienPurpleObj.position.set(0,46,0);
    alienPurpleObj.scale.set(3,3,3);
    alienPurpleObj.name = 'enemy';
    alienPurpleObj.visible = true;
    alienPurpleObj.traverse(function (child) {
        if (child) {
            child.castShadow = true;
        }
    alienPurpleObj.children.splice(5,1);
    playVector[4] = true;
    });
}, onProgress, null);

// loadGLTFObject(loadingManager, '../assets/objects/r2d2/scene.gltf');

function onProgress(xhr, model) {
    if (xhr.lengthComputable) {
        var percentComplete = xhr.loaded / xhr.total * 100;
    }
}

//********************************************//
var target = new THREE.Vector3();
//********************************************//
// Criando Adversários
var play = false; // Variável para verificar se o jogo pode começar
var passTime = false; // Variável para verificar se o tempo de 2 minutos já passou
var enemyVector = []; // Vetor de inimigos aereos
var groundEnemyVector = []; // Vetor de inimigos do chão
var curaVector = []; // Vetor de curas
// função para limitar quantos inimigos tem na tela
var cooldownsType = [false, true, true, true, true, true]
setTimeout( () => cooldownsType[1] = false, 5000);
setTimeout( () => cooldownsType[2] = false, 8000);
setTimeout( () => cooldownsType[3] = false, 10000);
setTimeout( () => cooldownsType[4] = false, 30000);
setTimeout( () => cooldownsType[5] = false, 6000);

function chamaAdversario() {
    if(!cooldownsType[0]) {
        cooldownsType[0] = true;
        setTimeout( () => cooldownsType[0] = false, 10000);
        criarAdversario(0);
    } else if (!cooldownsType[1]) {
        cooldownsType[1] = true;
        setTimeout( () => cooldownsType[1] = false, 25000);
        criarAdversario(1);
    } else if (!cooldownsType[2]) {
        cooldownsType[2] = true;
        setTimeout( () => cooldownsType[2] = false, 50000);
        criarAdversario(2);
    } else if (!cooldownsType[3]) {
        cooldownsType[3] = true;
        setTimeout( () => cooldownsType[3] = false, 45000);
        criarAdversario(3);
    }
    if(!cooldownsType[4]){
        cooldownsType[4] = true;
        setTimeout( () => cooldownsType[4] = false, 30000);
        criarAdversarioChao();
    }
}
function chamaCura() {
    if(!cooldownsType[5]) {
        cooldownsType[5] = true;
        setTimeout( () => cooldownsType[5] = false, 10000);
        criarCura(curaVector, scene);
    }
}

function criarAdversario(type) {
    let enemy = new EnemyAir(type);
    if(enemy.moveType === 0) {
        afterLoadEnemy(enemy, tecoTecoObj);
    } else if(enemy.moveType === 1) {
        afterLoadEnemy(enemy, tecoTecoObj);
    } else if(enemy.moveType === 2) {
        afterLoadEnemy(enemy, alienPurpleObj);
    } else if(enemy.moveType === 3) {
        afterLoadEnemy(enemy, tieFifhterObj);
    }
    var newpos = Math.floor(Math.random() * 95) + 1;
    const chance = Math.floor(Math.random() * 2) + 1;
    newpos = chance === 1 ? newpos : -newpos;
    enemy.setPosition(newpos);
    const velocidade = Math.floor(Math.random() * 5) + 2;
    enemy.setVelocity(velocidade);
    scene.add(enemy.mesh);
    enemyVector.push(enemy);
}
function criarAdversarioChao() {
    let enemy = new GroundEnemy();
    afterLoadEnemy(enemy, toonTankObj);
    var newpos = Math.floor(Math.random() * 95) + 1;
    //newpos = 30;
    const chance = Math.floor(Math.random() * 2) + 1;
    newpos = chance === 1 ? newpos : -newpos;
    enemy.setPosition(newpos);
    const velocidade = Math.floor(Math.random() * 5) + 2;
    enemy.setVelocity(velocidade);
    scene.add(enemy.mesh);
    groundEnemyVector.push(enemy);
}
function movimentarAdversario() {
    enemyVector.forEach(enemy => {
        let id = enemyVector.indexOf(enemy);
        enemy.move(enemyVector, id, scene);
    });
    groundEnemyVector.forEach(enemy => {
        let id = groundEnemyVector.indexOf(enemy);
        enemy.verticalChaoMove(groundEnemyVector, id ,scene);
    })
}
//********************************************//


// Funções para efetuar as animações de romoção da tela
function removePlane(){
    if(planeClass.mesh.scale.x>=0){
        planeClass.mesh.scale.x -=.1;
        planeClass.mesh.scale.y -=.1;
        planeClass.mesh.scale.z -=.1;
    }
    planeClass.deletePlane(scene, planeHolder);
    // planeHolder.geometry.dispose();
    scene.remove(planeHolder);
    //Parece que a boudingBox ainda ta na cena
}

function animation() {
    enemyVector.forEach(enemy => {
        enemy.animation(enemyVector, scene);
    });
    groundEnemyVector.forEach(enemy => {
        enemy.animation(groundEnemyVector, scene);
    })
    curaVector.forEach(cura => {
        if(cura.isCaught)
        if(cura.mesh.scale.x>=0){
            cura.mesh.scale.x -=.1;
            cura.mesh.scale.y -=.1;
            cura.mesh.scale.z -=.1;
        }
    });
}
//********************************************//
let cooldownBullet = false;
let cooldownMissile = false;
let pause = false;
function keyboardUpdate() {
    keyboard.update();
    
    if(keyboard.down("P")){
        pause = !pause;
        play = !play;
    }
    if(play){
        var speed = 40;
        var moveDistance = speed * clock.getDelta();
        planeClass.mesh.getWorldPosition(target);
        if (keyboard.pressed("down") && !passTime) {
            if (target.z <= 45) {
                planeClass.moveDown(moveDistance);
            }
        }
        if (keyboard.pressed("up") && !passTime) {
            if (target.z >= -150) {
                planeClass.moveUp(moveDistance);
            }
        }
        if (keyboard.pressed("right") && !passTime) {
            if (target.x <= 95) {
                planeClass.moveRight(moveDistance);
            }
        }
        if (keyboard.pressed("left") && !passTime) {
            if (target.x >= -95) {
                planeClass.moveLeft(moveDistance);
            }
        }
        if (keyboard.up("right") && !passTime) {
            planeClass.obj.rotateX(degreesToRadians(12));
        }
        if (keyboard.up("left") && !passTime) {
            planeClass.obj.rotateX(degreesToRadians(-12));
        }
        if (keyboard.down("G")) {
            planeClass.isMortal = !planeClass.isMortal;
        }
        if(keyboard.down("ctrl")) {
            planeClass.createShoot(scene);
        }
        else if (keyboard.pressed("ctrl") && !cooldownBullet){
            planeClass.createShoot(scene);
            cooldownBullet = true;
            setTimeout( () => cooldownBullet = false, 500);
        } 
        if(keyboard.down("space")){
            planeClass.createMissiles(scene);
        }
        else if (keyboard.pressed("space") && !cooldownMissile){
            planeClass.createMissiles(scene);
            cooldownMissile = true;
            setTimeout( () => cooldownMissile = false, 1000);
        }
        if (keyboard.pressed("enter")){
            play = false;
            enemyVector.forEach(enemy => {
                enemy.deleteAllBullets(scene);
                enemy.setIsDead(scene);
            });
            groundEnemyVector.forEach(enemy => {
                enemy.deleteAllMissiles(scene);
                enemy.setIsDead(scene);
            });
            curaVector.forEach(cura => {
                cura.setIsCaught();
            });
            planeClass.obj.position.set(0,16,0);
            planeClass.mesh.position.set(0,16,0);
            planeClass.obj.scale.set(1,1,1);
            scene.add(planeClass.obj);
            resetHealthBar(planeClass, vidas, scene);
            clock.elapsedTime = 0;
            passTime = false;
            play = true;
        }
    }
}
//********************************************//
window.addEventListener( 'resize', function(){onWindowResize(camera, renderer)}, false ); // Resize the screen
document.getElementById("webgl-output").appendChild(stats.domElement);//Pra mostrar o FPS
render();
//********************************************//
//Gerando viewport da vida
var vidas = [];
var geometry = new THREE.BoxGeometry(0.75, 1.5, 0.1);
var material = new THREE.MeshLambertMaterial({color:"rgb(0, 165, 0)"});
for (let i = 0; i < planeClass.vida; i++) {
    vidas[i] = new THREE.Mesh(geometry, material)
    vidas[i].position.set(-i*1.1+5, -200, 20);
    scene.add(vidas[i]);
    vidas.push(vidas[i]);
}

function validatePlay() {
    let count = 0;
    playVector.forEach(element => {
        if(element) {
            count++;
        }
    })
    // if(count === playVector.length && !pause) play = true;
}

function controlledRender()
{
  var width = window.innerWidth;
  var height = window.innerHeight;

  // Set main viewport
  renderer.setViewport(0, 0, width, height); // Reset viewport    
  renderer.setScissorTest(false); // Disable scissor to paint the entire window
  renderer.render(scene, camera);   

  // Set virtual camera viewport 
  var offset = -90; 
  renderer.setViewport(offset, height-vcHeidth-offset, vcWidth, vcHeidth);  // Set virtual camera viewport  
  renderer.setScissor(offset, height-vcHeidth-offset, vcWidth, vcHeidth); // Set scissor with the same size as the viewport
  renderer.setScissorTest(true); // Enable scissor to paint only the scissor are (i.e., the small viewport)
  renderer.render(scene, virtualCamera);  // Render scene of the virtual camera
}
var controls = new OrbitControls(camera, renderer.domElement);

function render() {
    stats.update();
    onWindowResize();

    if(!play) validatePlay();
    
    keyboardUpdate();
    if(play && !passTime){
        planos.moverPlanos();
        planeClass.moveBullets();
        planeClass.moveMissiles();
        planeClass.deleteBullets(scene);
        planeClass.deleteMissiles(scene);
        verticalCura(curaVector, scene);
        chamaAdversario(cooldownsType, enemyVector, groundEnemyVector);
        chamaCura();
        movimentarAdversario();
        enemyVector.forEach(element => {
            element.createEnemyShoot(scene);
            element.moveBullets(planeHolder);
            if(element.getPositionZ() > 45) {
                element.deleteAllBullets(scene);
            }
        });    
        groundEnemyVector.forEach(element => {
            element.createMissiles(scene);
            element.moveMissiles(planeHolder);
            if(element.getPositionZ() > 45) {
                element.deleteAllMissiles(scene);
            }
        });
        colisionBulletEnemy(planeClass, enemyVector, scene);
        colisionBulletPlane(enemyVector, planeClass, vidas, scene);
        colisionPlaneEnemy(enemyVector, planeClass, vidas, scene);
        colisionMissileEnemy(planeClass, groundEnemyVector, scene);
        colisionCuraPlane(curaVector, planeClass, vidas, scene);
        colisionMissilePlane(groundEnemyVector, planeClass, vidas, scene);
        animation();
        if(planeClass.vida <= 0){
            removePlane();
            play = false;
            passTime = true;
        }
    }
    if(clock.getElapsedTime() >= 120) {
        passTime = true;
    }
    requestAnimationFrame(render);
    controlledRender();
}